<?php
$conexion = mysqli_connect("127.0.0.1", "root", "", "base_usuarios", "3307");

if (!$conexion) {
    die("Error de conexion: " . mysqli_connect_error());
}
?>


