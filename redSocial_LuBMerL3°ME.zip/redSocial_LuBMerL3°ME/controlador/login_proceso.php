<?php
session_start();
include 'funciones.php';

$email = $_POST['email'];
$password = $_POST['password'];

if ($email == '' || $password == '') {
    $_SESSION['error'] = "Completa todos los campos";
    header('Location: ../vista/login.php');
    exit();
}

$usuario = buscarPorEmail($email);

if (!$usuario) {
    $_SESSION['error'] = "Email o contraseña incorrectos";
    header('Location: ../vista/login.php');
    exit();
}

if (password_verify($password, $usuario['usr_pass'])) {
    $_SESSION['usuario_id'] = $usuario['id'];
    $_SESSION['usuario_nombre'] = $usuario['usr_name'];
    $_SESSION['usuario_email'] = $usuario['usr_email'];
    $_SESSION['usuario_imagen'] = $usuario['imagen'];
    header('Location: ../vista/perfil.php');
} else {
    $_SESSION['error'] = "Email o contraseña incorrectos";
    header('Location: ../vista/login.php');
}
exit();
?>