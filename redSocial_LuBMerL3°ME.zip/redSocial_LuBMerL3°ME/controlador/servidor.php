<?php
session_start();
include 'funciones.php';

$accion = isset($_POST['accion']) ? $_POST['accion'] : '';

if ($accion == 'registro') {
    
    $nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirmar = isset($_POST['confirmarPassword']) ? $_POST['confirmarPassword'] : '';
    
    $_SESSION['form_nombre'] = $nombre;
    $_SESSION['form_email'] = $email;
    
    $errores = array();
    
    if ($nombre == '') {
        $errores[] = "El nombre es obligatorio";
    }
    
    if ($email == '') {
        $errores[] = "El email es obligatorio";
    }
    
    if ($password == '') {
        $errores[] = "La contraseña es obligatoria";
    } elseif (strlen($password) < 8) {
        $errores[] = "La contraseña debe tener al menos 8 caracteres";
    }
    
    if ($password != $confirmar) {
        $errores[] = "Las contraseñas no coinciden";
    }
    
    if (count($errores) == 0) {
        $existe = buscarPorEmail($email);
        if ($existe) {
            $errores[] = "Este email ya esta registrado";
        }
    }
    
    $nombreImagen = NULL;
    
    if (count($errores) == 0 && isset($_FILES['imagen']) && $_FILES['imagen']['error'] == 0) {
        $archivo = $_FILES['imagen'];
        $tipos = array('image/jpeg', 'image/png', 'image/gif');
        
        if (!in_array($archivo['type'], $tipos)) {
            $errores[] = "Solo se permiten imagenes JPG, PNG o GIF";
        } elseif ($archivo['size'] > 2 * 1024 * 1024) {
            $errores[] = "La imagen no debe superar los 2MB";
        } else {
            $extension = pathinfo($archivo['name'], PATHINFO_EXTENSION);
            $nombreImagen = 'perfil_' . time() . '.' . $extension;
            $ruta = '../vista/imagen_perfil/' . $nombreImagen;
            
            if (!move_uploaded_file($archivo['tmp_name'], $ruta)) {
                $errores[] = "Error al subir la imagen";
                $nombreImagen = NULL;
            }
        }
    }
    
    if (count($errores) > 0) {
        $_SESSION['error'] = implode('<br>', $errores);
        header('Location: ../vista/registro.php');
        exit();
    }
    
    $passHash = password_hash($password, PASSWORD_DEFAULT);
    $guardado = registrarUsuario($nombre, $email, $passHash, $nombreImagen);
    
    if ($guardado) {
        unset($_SESSION['form_nombre']);
        unset($_SESSION['form_email']);
        $_SESSION['exito'] = "Cuenta creada. Ahora inicia sesion.";
        header('Location: ../vista/login.php');
    } else {
        $_SESSION['error'] = "Error al registrar";
        header('Location: ../vista/registro.php');
    }
    exit();
}

if ($accion == 'publicar') {
    
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: ../vista/login.php');
        exit();
    }
    
    $mensaje = isset($_POST['mensaje']) ? trim($_POST['mensaje']) : '';
    
    if ($mensaje == '') {
        $_SESSION['error_pub'] = "El mensaje no puede estar vacio";
    } elseif (strlen($mensaje) > 500) {
        $_SESSION['error_pub'] = "El mensaje no puede superar los 500 caracteres";
    } else {
        $guardado = guardarPublicacion($_SESSION['usuario_id'], $mensaje);
        if ($guardado) {
            $_SESSION['exito_pub'] = "Publicacion creada";
        } else {
            $_SESSION['error_pub'] = "Error al publicar";
        }
    }
    
    header('Location: ../vista/perfil.php');
    exit();
}

header('Location: ../vista/login.php');
exit();
?>