<?php
include '../modelo/conexion.php';

function registrarUsuario($nombre, $email, $pass, $imagen) {
    global $conexion;
    $sql = "INSERT INTO usuario (usr_name, usr_email, usr_pass, imagen) 
            VALUES ('$nombre', '$email', '$pass', '$imagen')";
    return mysqli_query($conexion, $sql);
}

function buscarPorEmail($email) {
    global $conexion;
    $sql = "SELECT * FROM usuario WHERE usr_email = '$email'";
    $resultado = mysqli_query($conexion, $sql);
    return mysqli_fetch_assoc($resultado);
}

function buscarPorId($id) {
    global $conexion;
    $sql = "SELECT * FROM usuario WHERE id = $id";
    $resultado = mysqli_query($conexion, $sql);
    return mysqli_fetch_assoc($resultado);
}

function obtenerUsuarios() {
    global $conexion;
    $sql = "SELECT id, usr_name, usr_email, imagen FROM usuario ORDER BY usr_name ASC";
    $resultado = mysqli_query($conexion, $sql);
    $usuarios = [];
    while ($fila = mysqli_fetch_assoc($resultado)) {
        $usuarios[] = $fila;
    }
    return $usuarios;
}

function guardarPublicacion($usuario_id, $mensaje) {
    global $conexion;
    $sql = "INSERT INTO publicacion (usuario_id, mensaje) VALUES ($usuario_id, '$mensaje')";
    return mysqli_query($conexion, $sql);
}

function obtenerPublicaciones($usuario_id) {
    global $conexion;
    $sql = "SELECT * FROM publicacion WHERE usuario_id = $usuario_id ORDER BY fecha DESC";
    $resultado = mysqli_query($conexion, $sql);
    $publicaciones = [];
    while ($fila = mysqli_fetch_assoc($resultado)) {
        $publicaciones[] = $fila;
    }
    return $publicaciones;
}
?>