<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

include '../controlador/funciones.php';

$usuarios = obtenerUsuarios();
$publicaciones = obtenerPublicaciones($_SESSION['usuario_id']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil - Red Social</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="contenedor">
        <h2>Mi Perfil</h2>
        
        <?php if (!empty($_SESSION['usuario_imagen'])): ?>
            <img src="../imagen_perfil/<?php echo $_SESSION['usuario_imagen']; ?>" class="foto-perfil">
        <?php else: ?>
            <img src="../imagen_perfil/default.png" class="foto-perfil">
        <?php endif; ?>
        
        <div class="info-perfil">
            <h3><?php echo $_SESSION['usuario_nombre']; ?></h3>
            <p><?php echo $_SESSION['usuario_email']; ?></p>
        </div>
        
        <a href="../controlador/logout_proceso.php" class="btn-cerrar">Cerrar sesion</a>
        
        <hr>
        
        <h3>Crear Publicacion</h3>
        
        <?php if (isset($_SESSION['error_pub'])): ?>
            <div class="mensaje-error"><?php echo $_SESSION['error_pub']; unset($_SESSION['error_pub']); ?></div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['exito_pub'])): ?>
            <div class="mensaje-exito"><?php echo $_SESSION['exito_pub']; unset($_SESSION['exito_pub']); ?></div>
        <?php endif; ?>
        
        <form action="../controlador/servidor.php" method="POST">
            <input type="hidden" name="accion" value="publicar">
            <div class="grupo-campo">
                <label for="mensaje">Que estas pensando?</label>
                <textarea name="mensaje" id="mensaje" rows="3" class="textarea-publicacion"></textarea>
            </div>
            <button type="submit" class="btn-primario">Publicar</button>
        </form>
        
        <hr>
        
        <h3>Mis Publicaciones</h3>
        
        <?php if (empty($publicaciones)): ?>
            <p class="sin-publicaciones">No hay publicaciones todavia</p>
        <?php else: ?>
            <?php foreach ($publicaciones as $p): ?>
                <div class="publicacion">
                    <p><?php echo $p['mensaje']; ?></p>
                    <small><?php echo $p['fecha']; ?></small>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <hr>
        
        <div class="lista-usuarios">
            <h3>Usuarios registrados</h3>
            
            <?php foreach ($usuarios as $u): ?>
                <div class="usuario-item">
                    <?php if (!empty($u['imagen'])): ?>
                        <img src="../imagen_perfil/<?php echo $u['imagen']; ?>" alt="Foto">
                    <?php else: ?>
                        <img src="../imagen_perfil/default.png" alt="Sin foto">
                    <?php endif; ?>
                    
                    <a href="ver_perfil.php?id=<?php echo $u['id']; ?>">
                        <?php echo $u['usr_name']; ?>
                        <?php if ($u['id'] == $_SESSION['usuario_id']) echo ' (Yo)'; ?>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>