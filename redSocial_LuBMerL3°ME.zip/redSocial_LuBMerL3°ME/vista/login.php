<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Red Social</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="contenedor">
        <h2>Iniciar Sesion</h2>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="mensaje-error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['exito'])): ?>
            <div class="mensaje-exito"><?php echo $_SESSION['exito']; unset($_SESSION['exito']); ?></div>
        <?php endif; ?>
        
        <form action="../controlador/login_proceso.php" method="POST">
            <div class="grupo-campo">
                <label for="email">Correo electronico</label>
                <input type="email" name="email" id="email" required>
            </div>
            
            <div class="grupo-campo">
                <label for="password">Contraseña</label>
                <input type="password" name="password" id="password" required>
            </div>
            
            <button type="submit" class="btn-primario">Ingresar</button>
        </form>
        
        <p class="texto-centrado">
            No tenes cuenta? <a href="registro.php">Registrarse</a>
        </p>
    </div>
</body>
</html>