<?php
session_start();

if (!isset($_GET['id'])) {
    header('Location: perfil.php');
    exit();
}

include '../controlador/funciones.php';

$usuario = buscarPorId($_GET['id']);
$publicaciones = obtenerPublicaciones($_GET['id']);

if (!$usuario) {
    echo '<p style="text-align:center; margin-top:50px;">Usuario no encontrado.</p>';
    echo '<p style="text-align:center;"><a href="perfil.php">Volver</a></p>';
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de <?php echo $usuario['usr_name']; ?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="contenedor">
        <h2>Perfil de Usuario</h2>
        
        <?php if (!empty($usuario['imagen'])): ?>
            <img src="../imagen_perfil/<?php echo $usuario['imagen']; ?>" class="foto-perfil">
        <?php else: ?>
            <img src="../imagen_perfil/default.png" class="foto-perfil">
        <?php endif; ?>
        
        <div class="info-perfil">
            <h3><?php echo $usuario['usr_name']; ?></h3>
            <p><?php echo $usuario['usr_email']; ?></p>
        </div>
        
        <hr>
        
        <h3>Publicaciones</h3>
        
        <?php if (empty($publicaciones)): ?>
            <p class="sin-publicaciones">No hay publicaciones</p>
        <?php else: ?>
            <?php foreach ($publicaciones as $p): ?>
                <div class="publicacion">
                    <p><?php echo $p['mensaje']; ?></p>
                    <small><?php echo $p['fecha']; ?></small>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <a href="perfil.php" class="btn-secundario">← Volver a mi perfil</a>
    </div>
</body>
</html>