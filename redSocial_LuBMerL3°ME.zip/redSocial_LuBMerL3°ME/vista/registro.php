<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Red Social</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="contenedor">
        <h2>Crear Cuenta</h2>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="mensaje-error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        
        <form action="../controlador/servidor.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="accion" value="registro">
            
            <div class="grupo-campo">
                <label for="nombre">Nombre completo</label>
                <input type="text" name="nombre" id="nombre" required
                       value="<?php echo isset($_SESSION['form_nombre']) ? $_SESSION['form_nombre'] : ''; ?>">
            </div>
            
            <div class="grupo-campo">
                <label for="email">Correo electronico</label>
                <input type="email" name="email" id="email" required
                       value="<?php echo isset($_SESSION['form_email']) ? $_SESSION['form_email'] : ''; ?>">
            </div>
            
            <div class="grupo-campo">
                <label for="password">Contraseña</label>
                <input type="password" name="password" id="password" minlength="8" required>
            </div>
            
            <div class="grupo-campo">
                <label for="confirmarPassword">Confirmar contraseña</label>
                <input type="password" name="confirmarPassword" id="confirmarPassword" required>
            </div>
            
            <div class="grupo-campo">
                <label for="imagen">Foto de perfil (opcional)</label>
                <input type="file" name="imagen" id="imagen" accept="image/*">
            </div>
            
            <button type="submit" class="btn-primario">Registrarse</button>
        </form>
        
        <p class="texto-centrado">
            Ya tenes cuenta? <a href="login.php">Iniciar sesion</a>
        </p>
    </div>
</body>
</html>